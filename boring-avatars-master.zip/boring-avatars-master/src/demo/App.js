import React from 'react';
import Playground from './playground';

const App = () => (
  <Playground />
);

export default App;
